import './App.css';

function App() {
  return (
    <div className="App">
       <h1>this is thrid project</h1>
    </div>
  );
}

export default App;
